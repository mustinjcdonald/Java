
CREATE TABLE TeamAlpha.Cars 
(
	SerialNumber INT PRIMARY KEY NOT NULL,
	Make VARCHAR(255) NOT NULL,
	Model VARCHAR(255) NOT NULL,
	Year INT NOT NULL,
);

CREATE TABLE TeamAlpha.Summary
(
	ID INT PRIMARY KEY NOT NULL,
	SubTotal DECIMAL(19,2) NOT NULL
	SalesTax DECIMAL(19,2) NOT NULL
	GrandTotal DECIMAL(19,2) NOT NULL
);

INSERT INTO TeamAlpha.Cars (ID, Make, Model, Year) VALUES
		(1, 'Ferrari', 'Laferrari', '2018',),
		(2, 'Ferrari', 'F12', '2018',),
		(3, 'Ferrari', 'California', '2018',),
		(4, 'Ferrari', '488 Spider', '2018',),
		(5, 'Ferrari', '599 GTB', '2018',),
		(6, 'Lamborghini', 'Aventador', '2018',),
		(7, 'Lamborghini', 'Urus', '2018',),
		(8, 'Lamborghini', 'Veneno', '2018',),
		(9, 'Lamborghini', 'Centenario', '2018',),
		(10, 'Lamborghini', 'Hurracan', '2018',),
		(11, 'Mercedes', 'C63 AMG', '2018',),
		(12, 'Mercedes', 'G-Wagon', '2018',),
		(13, 'Mercedes', 'CLS', '2018',),
		(14, 'Mercedes', 'AMG GT', '2018',),
		(15, 'Mercedes', 'A-Class', '2018',),
		(16, 'Audi', 'R8', '2018',);
		(17, 'Audi', 'S4', '2018',),
		(18, 'Audi', 'TTRS', '2018',),
		(19, 'Audi', 'A6 ', '2018',),
		(20, 'Audi', 'RS5 Quattro', '2018',);
SELECT * FROM TeamAlpha.Customer;
